﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Weekend_Project.Model;

namespace Weekend_Project
{
    public partial class Form4 : Form
    {
        CompanyLogic ob;
        public Form4()
        {
            InitializeComponent();
            ob = new CompanyLogic();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }
        private void btndelete_Click(object sender, EventArgs e)
        {

            int i;
            i = Convert.ToInt32(tbempid.Text);
            bool es = ob.check(i);
            if (es)
            {
                string msg = ob.deletesp(i);
                if (msg != null)
                {
                    MessageBox.Show(msg);
                    dataGridView1.Visible = true;
                    dataGridView1.DataSource = ob.getAllData();
                }
                else
                {
                    MessageBox.Show("unable to fetch data....");
                }
            }
            else
            {
                MessageBox.Show("Enter valid EmpID");

            }
        }
    }
}
