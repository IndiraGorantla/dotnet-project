﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Weekend_Project.Model;

namespace Weekend_Project
{
  
    public partial class Form3 : Form
    {
        CompanyLogic ob;
        public Form3()
        {
            InitializeComponent();
            ob = new CompanyLogic();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Employee ep  = new Employee();
            ep.EMPID = Convert.ToInt32(tbempid.Text);
            ep.EMPNAME = tbname.Text.ToString();
            ep.DOB = Convert.ToDateTime(tbdob.Text);
            ep.PHONE = Convert.ToInt64(tbphone.Text);
            ep.EMAIL = tbemail.Text.ToString();
            ep.SALARY = float.Parse(tbsalary.Text);
            ep.DEPTID = Convert.ToInt32(tbdeptid.Text);
            ob.updatedata(ep);
            dataGridView1.DataSource = ob.getAllData();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
           
        }
    }
}
