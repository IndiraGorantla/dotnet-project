﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Weekend_Project.Model;

namespace Weekend_Project
{
    public partial class Form6 : Form
    {
        CompanyLogic ob;
        public Form6()
        {
            InitializeComponent();
            ob = new CompanyLogic();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            string name = tbname.Text.ToString();
            Employee ep = ob.search(name);
            if (ep == null)
            {
                MessageBox.Show("No data present");
            }
            else
            {
                List<Employee> li = new List<Employee>();
                li.Add(ep);
                MessageBox.Show("data is present");
                dataGridView1.Visible = true;
                dataGridView1.DataSource = li;
            }
            tbname.Text = "";
        }
    }
}
