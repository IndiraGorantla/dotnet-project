﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Weekend_Project.Model;

namespace Weekend_Project
{
    public partial class Form2 : Form
    {
        CompanyLogic ob;
        public Form2()
        {
            InitializeComponent();
            ob = new CompanyLogic();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllDetails();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            d.DEPTID = Convert.ToInt32(tbdeptid.Text);
            d.DEPTNAME = tbdeptname.Text.ToString();
            d.DEPTLOCATION = tbdeptloc.Text.ToString();
            d.MANAGERID = Convert.ToInt32(tbmanid.Text);
            string message = ob.spInsertDepartment(d);
            MessageBox.Show(message);
            dataGridView1.DataSource = ob.getAllDetails();
            tbdeptid.Text = "";
            tbdeptname.Text = "";
            tbdeptloc.Text = "";
            tbmanid.Text = "";

        }
    }
}
