﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Weekend_Project.Model;

namespace Weekend_Project
{
    public partial class Form5 : Form
    {
        CompanyLogic ob;
        public Form5()
        {
            InitializeComponent();
            ob = new CompanyLogic();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            float salary = Convert.ToInt32(tbsalary.Text);
            Employee emp = ob.search(salary);
            if (emp == null)
            {
                MessageBox.Show("No data is present");
            }
            else
            {
                List<Employee> li = new List<Employee>();
                li.Add(emp);
                MessageBox.Show("data is present");
                dataGridView1.Visible = true;
                dataGridView1.DataSource = li;
            }
            tbsalary.Text = "";

        }
    }
}
