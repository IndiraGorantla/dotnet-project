﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Weekend_Project.Model
{

    //INSERTION PART OF EMPLOYEE TABLE

    class CompanyLogic
    {
        private string constr = ConfigurationManager.ConnectionStrings
            ["Companydb"].ConnectionString;

        public List<Employee> getAllData()
        {
            List<Employee> ob = new List<Employee>();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Employee";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Employee e = new Employee();
                    e.EMPID = Convert.ToInt32(reader.GetValue(0));
                    e.EMPNAME = reader.GetValue(1).ToString();
                    e.DOB = Convert.ToDateTime(reader.GetValue(2));
                    e.PHONE = Convert.ToInt64(reader.GetValue(3));
                    e.EMAIL = reader.GetValue(4).ToString();
                    e.SALARY = Convert.ToInt32(reader.GetValue(5));
                    e.DEPTID = Convert.ToInt32(reader.GetValue(6));

                    ob.Add(e);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("COULDNT CONNECT TO DB");
            }
            finally
            {
                conn.Close();
            }


            return ob;

        }

      
        public string spInsertEmployee(Employee ep)
        {
            string message = null;

            SqlConnection conn = new SqlConnection(constr);

            string sql = "spInsertEmployee";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@empid", SqlDbType.Int).Value = ep.EMPID;
                cmd.Parameters.Add("@empname", SqlDbType.VarChar, 50).Value = ep.EMPNAME;
                cmd.Parameters.Add("@dob", SqlDbType.Date).Value = ep.DOB;
                cmd.Parameters.Add("@phone", SqlDbType.BigInt).Value = ep.PHONE;
                cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = ep.EMAIL;
                cmd.Parameters.Add("@salary", SqlDbType.Float).Value = ep.SALARY;
                cmd.Parameters.Add("@deptid", SqlDbType.Int).Value = ep.DEPTID;
                cmd.ExecuteNonQuery();

                message = " data inserted successfully";
            }
            catch (Exception)
            {
                message = "Couldn't insert the data!!";
            }
            finally
            {
                conn.Close();
            }


            return message;


        }


        //INSERTION PART OF DEPARTMENT TABLE


        public List<Department> getAllDetails()
        {
            List<Department> ob = new List<Department>();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Department";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Department d = new Department();
                    d.DEPTID = Convert.ToInt32(reader.GetValue(0));
                    d.DEPTNAME = reader.GetValue(1).ToString();
                    d.DEPTLOCATION = reader.GetValue(2).ToString();
                    d.MANAGERID = Convert.ToInt32(reader.GetValue(3));

                    ob.Add(d);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("COULDNT CONNECT TO DB");
            }
            finally
            {
                conn.Close();
            }


            return ob;

        }


        public string spInsertDepartment(Department d)
        {
            string message = null;

            SqlConnection conn = new SqlConnection(constr);

            string sql = "spInsertDepartment";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@deptid", SqlDbType.Int).Value = d.DEPTID;
                cmd.Parameters.Add("@deptname", SqlDbType.VarChar, 50).Value = d.DEPTNAME;
                cmd.Parameters.Add("@deptlocation", SqlDbType.VarChar, 50).Value = d.DEPTLOCATION;
                cmd.Parameters.Add("@managerid", SqlDbType.Int).Value = d.MANAGERID;
                cmd.ExecuteNonQuery();

                message = " data inserted successfully";
            }
            catch (Exception)
            {
                message = "Couldn't insert the data!!";
            }
            finally
            {
                conn.Close();
            }


            return message;

        }



        //CHECK AND UPDATE PART OF EMPLOYEE TABLE


        public void updatedata(Employee e)
        {
            SqlConnection conn = new SqlConnection(constr);
            string sql = "spUpdate";
            ; try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@empid", SqlDbType.Int).Value = e.EMPID;
                cmd.Parameters.Add("@empname", SqlDbType.VarChar, 50).Value = e.EMPNAME;
                cmd.Parameters.Add("@dob", SqlDbType.Date).Value = e.DOB;
                cmd.Parameters.Add("@phone", SqlDbType.BigInt).Value = e.PHONE;
                cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = e.EMAIL;
                cmd.Parameters.Add("@salary", SqlDbType.Float).Value = e.SALARY;
                cmd.Parameters.Add("@deptid", SqlDbType.Int).Value = e.DEPTID;
                cmd.ExecuteNonQuery();
                MessageBox.Show("updated the record");

            }
            catch (Exception)
            {
                MessageBox.Show("cannot update!!!");

            }
            finally
            {
                conn.Close();
            }
        }


        //DELETE WITH RESPECT TO EMPLOYEE ID  

        public bool check(int i)
        {
            bool x = false;
            string sql = "select * from Employee where EMPID=" + i;
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmdd = new SqlCommand(sql, conn);
                SqlDataReader sqrr = cmdd.ExecuteReader();
                if (sqrr.HasRows)
                {
                    x = true;
                }
                else
                {
                    x = false;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't find data");
            }
            finally
            {
                conn.Close();
            }
            return x;
        }


        public string deletesp(int id)
        {
            string msg = "";
            string sql = "spdeleteemployee";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EMPID", id);
                cmd.ExecuteNonQuery();
                msg = "Data Deleted Successfully";
            }
            catch (Exception)
            {
                MessageBox.Show("unable to delete data");
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }

        //SEARCH USING EMPLOYEE SALARY

        public Employee search(float salary)
        {
            Employee ob = new Employee();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Employee where salary=" + salary;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        ob.EMPID = Convert.ToInt32(reader.GetValue(0));
                        ob.EMPNAME = reader.GetValue(1).ToString();
                        ob.DOB = Convert.ToDateTime(reader.GetValue(2));
                        ob.PHONE = Convert.ToInt64(reader.GetValue(3));
                        ob.EMAIL = reader.GetValue(4).ToString();
                        ob.SALARY = Convert.ToInt32(reader.GetValue(5));
                        ob.DEPTID = Convert.ToInt32(reader.GetValue(6));
                    }

                }
                else
                {
                    ob = null;

                }

            }
            catch (Exception)
            {
                MessageBox.Show("COULDNT CONNECT TO DB");
            }
            finally
            {
                conn.Close();
            }


            return ob;

        }



        // //SEARCH USING EMPLOYEE NAME


        public Employee search(string str)
        {
            Employee ob = new Employee();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Employee where EMPNAME='" + str + "'";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        ob.EMPID = Convert.ToInt32(reader.GetValue(0));
                        ob.EMPNAME = reader.GetValue(1).ToString();
                        ob.DOB = Convert.ToDateTime(reader.GetValue(2));
                        ob.PHONE = Convert.ToInt64(reader.GetValue(3));
                        ob.EMAIL = reader.GetValue(4).ToString();
                        ob.SALARY = Convert.ToInt32(reader.GetValue(5));
                        ob.DEPTID = Convert.ToInt32(reader.GetValue(6));
                    }

                }
                else
                {
                    ob = null;

                }

            }
            catch (Exception)
            {
                MessageBox.Show("COULDNT CONNECT TO DB");
            }
            finally
            {
                conn.Close();
            }


            return ob;

        }

        // MANAGER DETAILS

        public DataTable getjointable()
        {
            DataTable merge = new DataTable("tablejoin");
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select E.EMPNAME,E.DOB,E.PHONE,E.EMAIL,E.SALARY, D.DEPTNAME," +
                "D.DEPTLOCATION FROM EMPLOYEE E INNER JOIN DEPARTMENT D ON E.EMPID=D.MANAGERID";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(merge);
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to fetch data");
            }
            finally
            {
                conn.Close();
            }
            return merge;
        }



    }
}