﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weekend_Project.Model
{
    class Employee
    {
        public int EMPID { get; set; }
        public string EMPNAME { get; set; }
        public DateTime DOB { get; set; }
        public Int64 PHONE { get; set; }
        public string EMAIL { get; set; }
        public float SALARY { get; set; }
        public int DEPTID { get; set; }

    
    }

    class Department
    {
        public int DEPTID { get; set; }
        public string DEPTNAME { get; set; }
        public string DEPTLOCATION { get; set; }
        public int MANAGERID { get; set; }

    }
}
